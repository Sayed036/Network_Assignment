
**Organization:** Orbit Logistics (`10.99.0.0/24`, Variant `N = 99`, Fault Set A)  
**Deliverables:** `A1_SetA_fixed.pkt` and `A1_fixes.md`

---

## Part 1: VLSM Verification & Summary Route Calculation (5 Marks)

### 1.1 VLSM Allocation Verification (`10.99.0.0/24`)

Base block: `10.99.0.0/24` (256 total addresses: `10.99.0.0` – `10.99.0.255`).

| # | Subnet | VLAN | Req. Hosts | Network / Prefix | Subnet Mask | Wildcard Mask | Usable Host Range | Broadcast | Usable Hosts | Gateway | Valid? |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | HQ-STAFF | 10 | 50 | `10.99.0.0/26` | `255.255.255.192` | `0.0.0.63` | `10.99.0.1 – 10.99.0.62` | `10.99.0.63` | 62 | `10.99.0.1` (`HQ-R1 G0/0.10`) | Pass (62 ≥ 50) |
| 2 | HQ-SERVERS | 20 | 20 | `10.99.0.64/27` | `255.255.255.224` | `0.0.0.31` | `10.99.0.65 – 10.99.0.94` | `10.99.0.95` | 30 | `10.99.0.65` (`HQ-R1 G0/0.20`) | Pass (30 ≥ 20) |
| 3 | HQ-GUEST | 30 | 25 | `10.99.0.96/27` | `255.255.255.224` | `0.0.0.31` | `10.99.0.97 – 10.99.0.126` | `10.99.0.127` | 30 | `10.99.0.97` (`HQ-R1 G0/0.30`) | Pass (30 ≥ 25) |
| 4 | BRA-STAFF | 10 | 28 | `10.99.0.128/27` | `255.255.255.224` | `0.0.0.31` | `10.99.0.129 – 10.99.0.158` | `10.99.0.159` | 30 | `10.99.0.129` (`BRA-R1 G0/0.10`) | Pass (30 ≥ 28) |
| 5 | BRB-STAFF | 10 | 28 | `10.99.0.160/27` | `255.255.255.224` | `0.0.0.31` | `10.99.0.161 – 10.99.0.190` | `10.99.0.191` | 30 | `10.99.0.161` (`BRB-R1 G0/0.10`) | Pass (30 ≥ 28) |
| 6 | BRA-GUEST | 30 | 12 | `10.99.0.192/28` | `255.255.255.240` | `0.0.0.15` | `10.99.0.193 – 10.99.0.206` | `10.99.0.207` | 14 | `10.99.0.193` (`BRA-R1 G0/0.30`) | Pass (14 ≥ 12) |
| 7 | BRB-GUEST | 30 | 12 | `10.99.0.208/28` | `255.255.255.240` | `0.0.0.15` | `10.99.0.209 – 10.99.0.222` | `10.99.0.223` | 14 | `10.99.0.209` (`BRB-R1 G0/0.30`) | Pass (14 ≥ 12) |
| 8 | WAN1 (HQ–BRA) | — | 2 | `10.99.0.224/30` | `255.255.255.252` | `0.0.0.3` | `10.99.0.225 – 10.99.0.226` | `10.99.0.227` | 2 | `.225` (`HQ-R1 G0/1`), `.226` (`BRA-R1 G0/1`) | Pass (2 ≥ 2) |
| 9 | WAN2 (BRA–BRB) | — | 2 | `10.99.0.228/30` | `255.255.255.252` | `0.0.0.3` | `10.99.0.229 – 10.99.0.230` | `10.99.0.231` | 2 | `.229` (`BRA-R1 G0/2`), `.230` (`BRB-R1 G0/1`) | Pass (2 ≥ 2) |

**VLSM Audit Summary:**
- **Address Accounting:** `64 + 32 + 32 + 32 + 32 + 16 + 16 + 4 + 4 = 232` addresses allocated (`10.99.0.0` – `10.99.0.231`), with `24` addresses remaining unallocated (`10.99.0.232` – `10.99.0.255`).
- **Overlap & Alignment Check:** Zero overlaps; every subnet starts on an exact CIDR block boundary (multiples of 64, 32, 16, and 4) and meets host requirements with minimal waste.

### 1.2 Exact Summary Route & Wildcard Mask Covering `BRA-STAFF` and `BRB-STAFF`

Binary comparison of the fourth octet (first three octets `10.99.0` = 24 identical bits):

- `BRA-STAFF`: `10.99.0.128/27` -> `10.99.0.` **`10`**`000000` (covers `.128` – `.159`)
- `BRB-STAFF`: `10.99.0.160/27` -> `10.99.0.` **`10`**`100000` (covers `.160` – `.191`)

The first **26 bits** (`24 + 2`) match exactly:
- **Exact Summary Route:** `10.99.0.128/26`
- **Subnet Mask:** `255.255.255.192`
- **Wildcard Mask:** `0.0.0.63`
- **Exact Range Covered:** `10.99.0.128` – `10.99.0.191` (64 addresses = exact union of `BRA-STAFF` and `BRB-STAFF` with zero extra subnets included).

---

## Part 2: Fault Diagnosis, Root Causes & Fixes (30 Marks)

> **Audit Note:** Exhaustive inspection of every router (`HQ-R1`, `BRA-R1`, `BRB-R1`, `ISP-R1`), switch (`HQ-SW1`, `BRA-SW1`, `BRB-SW1`), host (`HQ-PC1`, `HQ-PC2`, `BRA-PC1`, `BRA-PC2`, `BRB-PC1`, `BRB-PC2`, `HQ-SRV1`, `Internet-Server`), link, VLAN database, DHCP pool, OSPF configuration, NAT configuration, ACL, and SSH/VTY setting in `Copy of A1_Starter_SetA.pkt` identified **9 injected faults** (4 Easy, 3 Medium, 2 Hard). Every fault is fixed in place in `A1_SetA_fixed.pkt` with both `running-config` and `startup-config` synchronized.

### Summary Table of Faults

| # | Severity | Device | Interface / Component | Root Cause |
|---|---|---|---|---|
| 1 | Easy | `HQ-R1` | `GigabitEthernet0/2` | ISP uplink interface is administratively `shutdown` |
| 2 | Easy | `BRA-R1` | `GigabitEthernet0/0.30` | Branch A Guest subinterface (VLAN 30) is administratively `shutdown` |
| 3 | Easy | `HQ-SW1` | `FastEthernet0/2` | `HQ-PC1` access port is assigned to `VLAN 20` instead of `VLAN 10` |
| 4 | Easy | `HQ-SRV1` | Static IP Configuration | Default gateway is set to `10.99.0.94` instead of `10.99.0.65` |
| 5 | Medium | `BRB-SW1` | `FastEthernet0/1` | Trunk allowed VLAN list is `10` only (missing `VLAN 30`) |
| 6 | Medium | `BRB-R1` | `ip dhcp pool BRB_STAFF` | `default-router` is `10.99.0.162` instead of `10.99.0.161` |
| 7 | Medium | `HQ-R1` | `router ospf 10` | `passive-interface default` without `no passive-interface GigabitEthernet0/1` |
| 8 | Hard | `HQ-R1` | `ip access-list standard NAT_INSIDE` | Wildcard mask is `0.0.0.127` (`/25`) instead of `0.0.0.255` (`/24`), excluding Branches A & B |
| 9 | Hard | `HQ-R1` | `GigabitEthernet0/0.20` | `SERVERS_OUT` ACL is applied `in` instead of `out`, dropping all return traffic from `HQ-SRV1` |

---

### Fault 1 (Easy) - `HQ-R1`: ISP Uplink Interface Administratively Shut Down

- **Device:** `HQ-R1` (`GigabitEthernet0/2`)
- **Symptom:** No device on Orbit Logistics' network can reach `ISP-R1` (`203.0.113.1`) or `Internet-Server` (`198.51.100.10` / `www.orbit.test`). Additionally, `HQ-R1` does not install its static default route (`0.0.0.0/0 -> 203.0.113.1`) into the RIB, preventing `default-information originate` from advertising a default route via OSPF to `BRA-R1` and `BRB-R1`.
- **Root Cause:** `interface GigabitEthernet0/2` (`203.0.113.2/30`, `ip nat outside`) is configured with `shutdown`.
- **CLI Fix:**
  ```ios
  HQ-R1# configure terminal
  HQ-R1(config)# interface GigabitEthernet0/2
  HQ-R1(config-if)# no shutdown
  HQ-R1(config-if)# end
  HQ-R1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  HQ-R1# show ip interface brief | include GigabitEthernet0/2
  GigabitEthernet0/2     203.0.113.2     YES manual up                    up

  HQ-R1# ping 203.0.113.1
  Type escape sequence to abort.
  Sending 5, 100-byte ICMP Echos to 203.0.113.1, timeout is 2 seconds:
  .!!!!
  Success rate is 80 percent (4/5), round-trip min/avg/max = 0/0/0 ms

  HQ-R1#ping 203.0.113.1

  Type escape sequence to abort.
  Sending 5, 100-byte ICMP Echos to 203.0.113.1, timeout is 2 seconds:
  !!!!!
  Success rate is 100 percent (5/5), round-trip min/avg/max = 0/0/0 ms

  HQ-R1# show ip route static
  S*   0.0.0.0/0 [1/0] via 203.0.113.1
  ```

---

### Fault 2 (Easy) - `BRA-R1`: Branch A Guest Subinterface Administratively Shut Down

- **Device:** `BRA-R1` (`GigabitEthernet0/0.30`)
- **Symptom:** `BRA-PC2` (on `BRA-SW1 Fa0/10`, VLAN 30) fails DHCP discovery (falls back to APIPA `169.254.x.x`) and cannot ping its gateway `10.99.0.193` or reach the Internet.
- **Root Cause:** `interface GigabitEthernet0/0.30` (`encapsulation dot1Q 30`, `10.99.0.193/28`) is configured with `shutdown`.
- **CLI Fix:**
  ```ios
  BRA-R1# configure terminal
  BRA-R1(config)# interface GigabitEthernet0/0.30
  BRA-R1(config-subif)# no shutdown
  BRA-R1(config-subif)# end
  BRA-R1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  BRA-R1# show ip interface brief | include GigabitEthernet0/0.30
  GigabitEthernet0/0.30  10.99.0.193     YES manual up                    up
  ```
  On `BRA-PC2`, renew DHCP (`ipconfig /renew`): receives IP in `10.99.0.194/28`, Gateway `10.99.0.193`, DNS `198.51.100.10`.
  
  **After that till now, everything is good but i cannot ping BRA-R1(10.99.0.193), BRA-PC1  from BRA-PC2, somehow host is unreachable maybe due to ACL. Maybe it is another Bug, Sorry i did not see the assignment carefully it is not a Bug. i just wasted my 4 hour :(** 

---

### Fault 3 (Easy) - `HQ-SW1`: `HQ-PC1` Assigned to Wrong VLAN

- **Device:** `HQ-SW1` (`FastEthernet0/2`)
- **Symptom:** `HQ-PC1` (expected in `HQ-STAFF`, VLAN 10, `10.99.0.0/26`) cannot obtain a DHCP lease from `HQ-R1`'s `HQ_STAFF` pool because VLAN 20 (`HQ-SERVERS`) has no DHCP pool, so `HQ-PC1` falls back to APIPA and loses all connectivity.
- **Root Cause:** `interface FastEthernet0/2` on `HQ-SW1` is configured with `switchport access vlan 20` instead of `switchport access vlan 10`.
- **CLI Fix:**
  ```ios
  HQ-SW1# configure terminal
  HQ-SW1(config)# interface FastEthernet0/2
  HQ-SW1(config-if)# switchport access vlan 10
  HQ-SW1(config-if)# end
  HQ-SW1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  HQ-SW1# show vlan brief
  10   STAFF                            active    Fa0/2, Fa0/3, Fa0/4, Fa0/5, Fa0/6, Fa0/7, Fa0/8, Fa0/9
  ```
  On `HQ-PC1`, run `ipconfig /renew`:    IP Address......................: 10.99.0.2
   Subnet Mask.....................: 255.255.255.192
   Default Gateway.................: 10.99.0.1
   DNS Server......................: 198.51.100.10

   ping 10.99.0.1(from HQ-PC1 to HQ-R1)

  Pinging 10.99.0.1 with 32 bytes of data:

  Reply from 10.99.0.1: bytes=32 time<1ms TTL=255
  Reply from 10.99.0.1: bytes=32 time<1ms TTL=255
  Reply from 10.99.0.1: bytes=32 time<1ms TTL=255

---

### Fault 4 (Easy) - `HQ-SRV1`: Incorrect Static Default Gateway

- **Device:** `HQ-SRV1` (Server IP Configuration)
- **Symptom:** `HQ-SRV1` (`10.99.0.66/27`) cannot reply to pings or HTTP requests from any off-subnet host (`HQ-PC1`, `BRA-PC1`, `BRB-PC1`) and cannot reach `Internet-Server` (`198.51.100.10`), even after fixing `SERVERS_OUT` on `HQ-R1`.
- **Root Cause:** `HQ-SRV1`'s static Default Gateway is configured as `10.99.0.94` (an unassigned host IP at the top of `10.99.0.64/27`) instead of `10.99.0.65` (`HQ-R1 G0/0.20`).
- **Fix (Packet Tracer Desktop -> IP Configuration):**
  - Change **Default Gateway** from `10.99.0.94` to `10.99.0.65` (keep IP `10.99.0.66`, Subnet Mask `255.255.255.224`, DNS Server `198.51.100.10`).
- **Verification Command & Expected Output (on `HQ-SRV1` Command Prompt):**
  ```text
  C:\> ipconfig
  IP Address......................: 10.99.0.66
  Subnet Mask.....................: 255.255.255.224
  Default Gateway.................: 10.99.0.65

  C:\>ping 10.99.0.65

  Pinging 10.99.0.65 with 32 bytes of data:

  Reply from 10.99.0.65: bytes=32 time<1ms TTL=255
  Reply from 10.99.0.65: bytes=32 time<1ms TTL=255

  Ping statistics for 10.99.0.65:
  Packets: Sent = 2, Received = 2, Lost = 0 (0% loss),
  Approximate round trip times in milli-seconds:
  Minimum = 0ms, Maximum = 0ms, Average = 0ms

- **(all Device(BRA-pc1, BRB-pc1, HQ-pc1) working fine, took me much more time to fix this)    )**
  ```

---

### Fault 5 (Medium) - `BRB-SW1`: Trunk Missing VLAN 30 in Allowed List

- **Device:** `BRB-SW1` (`FastEthernet0/1`)
- **Symptom:** `BRB-PC2` (on `BRB-SW1 Fa0/10`, VLAN 30) cannot obtain a DHCP lease from `BRB-R1` (`BRB_GUEST`) or reach its default gateway `10.99.0.209`, while `BRB-PC1` (VLAN 10) receives DHCP normally.
- **Root Cause:** The 802.1Q trunk on `BRB-SW1 Fa0/1` to `BRB-R1 G0/0` is configured with `switchport trunk allowed vlan 10`, pruning VLAN 30 (`GUEST`) frames before they can reach `BRB-R1 G0/0.30`.
- **CLI Fix:**
  ```ios
  BRB-SW1# configure terminal
  BRB-SW1(config)# interface FastEthernet0/1
  BRB-SW1(config-if)# switchport trunk allowed vlan 10,30
  BRB-SW1(config-if)# end
  BRB-SW1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  BRB-SW1#sh int trunk 
  Port        Mode         Encapsulation  Status        Native vlan
  Fa0/1       on           802.1q         trunking      998

  Port        Vlans allowed on trunk
  Fa0/1       10,30

  Port        Vlans allowed and active in management domain
  Fa0/1       10,30

  Port        Vlans in spanning tree forwarding state and not pruned
  Fa0/1       10,30
  ```
  On `BRB-PC2`, run `ipconfig /renew`: receives IP in `10.99.0.210–222/28`, Gateway `10.99.0.209`, DNS `198.51.100.10`.

- * I can say it was easy for me, just setting up vlan 10,30 as trunk for DHCP**

---

### Fault 6 (Medium) - `BRB-R1`: Wrong Default Gateway in DHCP Pool `BRB_STAFF`

- **Device:** `BRB-R1` (`ip dhcp pool BRB_STAFF`)
- **Symptom:** `BRB-PC1` obtains a valid IP in `10.99.0.160/27` via DHCP and can ping `BRB-R1 G0/0.10` (`10.99.0.161`) directly, but fails to reach any remote subnet (`BRA-PC1`, `HQ-PC1`, `HQ-SRV1`, `Internet-Server`) because its default route points to a non-existent host (`10.99.0.162`).
- **Root Cause:** Under `ip dhcp pool BRB_STAFF`, `default-router 10.99.0.162` is configured instead of `BRB-R1 G0/0.10`'s actual IP `10.99.0.161`.
- **CLI Fix:**
  ```ios
  BRB-R1# configure terminal
  BRB-R1(config)# ip dhcp pool BRB_STAFF
  BRB-R1(dhcp-config)# default-router 10.99.0.161
  BRB-R1(dhcp-config)# end
  BRB-R1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  BRB-R1# show running-config | section ip dhcp pool BRB_STAFF
  ip dhcp pool BRB_STAFF
   network 10.99.0.160 255.255.255.224
   default-router 10.99.0.161
   dns-server 198.51.100.10
  ```
  On `BRB-PC1`, run `ipconfig /release` then `ipconfig /renew`: Default Gateway updates to `10.99.0.161`.

---

### Fault 7 (Medium) - `HQ-R1`: OSPF WAN1 Interface Left Passive

- **Device:** `HQ-R1` (`router ospf 10`)
- **Symptom:** `HQ-R1` forms no OSPF neighbor adjacency with `BRA-R1` over WAN1 (`10.99.0.224/30`). `HQ-R1` has no routes to Branch A (`10.99.0.128/27`, `.192/28`), Branch B (`10.99.0.160/27`, `.208/28`), or WAN2 (`10.99.0.228/30`), and `BRA-R1`/`BRB-R1` have no routes to HQ subnets or the `0.0.0.0/0` default route. (Meanwhile, `BRA-R1` and `BRB-R1` form an OSPF adjacency over WAN2 normally.)
- **Root Cause:** `router ospf 10` on `HQ-R1` specifies `passive-interface default` without exempting the WAN1 interface (`no passive-interface GigabitEthernet0/1`), suppressing all OSPF Hello packets on `G0/1`.
- **CLI Fix:**
  ```ios
  HQ-R1# configure terminal
  HQ-R1(config)# router ospf 10
  HQ-R1(config-router)# no passive-interface GigabitEthernet0/1
  HQ-R1(config-router)# end
  HQ-R1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  HQ-R1# show ip ospf neighbor
  Neighbor ID     Pri   State           Dead Time   Address         Interface
  2.2.2.2           0   FULL/  -        00:00:38    10.99.0.226     GigabitEthernet0/1

  BRA-R1# show ip route ospf
  O    10.99.0.0/26 [110/2] via 10.99.0.225, GigabitEthernet0/1
  O    10.99.0.64/27 [110/2] via 10.99.0.225, GigabitEthernet0/1
  O    10.99.0.96/27 [110/2] via 10.99.0.225, GigabitEthernet0/1
  O    10.99.0.160/27 [110/2] via 10.99.0.230, GigabitEthernet0/2
  O    10.99.0.208/28 [110/2] via 10.99.0.230, GigabitEthernet0/2
  O*E2 0.0.0.0/0 [110/1] via 10.99.0.225, GigabitEthernet0/1
  ```

---

### Fault 8 (Hard) - `HQ-R1`: Truncated Wildcard Mask in `NAT_INSIDE` ACL

- **Device:** `HQ-R1` (`ip access-list standard NAT_INSIDE`)
- **Symptom:** After OSPF and `HQ-R1 G0/2` are restored, HQ hosts (`HQ-PC1`, `HQ-PC2`) can resolve `www.orbit.test` and reach `Internet-Server` (`198.51.100.10`), **but all Branch A and Branch B hosts (`BRA-PC1`, `BRA-PC2`, `BRB-PC1`, `BRB-PC2`) fail to reach `198.51.100.10`**. Packets from branches reach `HQ-R1` and exit `G0/2` untranslated with private RFC 1918 source IPs (`10.99.0.128–222`), which `ISP-R1` has no return route for.
- **Root Cause:** Standard ACL `NAT_INSIDE` contains `permit 10.99.0.0 0.0.0.127`, which only matches `10.99.0.0/25` (`10.99.0.0 – 10.99.0.127`, covering HQ only) instead of the entire `10.99.0.0/24` block (`0.0.0.255`). This fault is hidden until OSPF (Fault 7) and `HQ-R1 G0/2` (Fault 1) are repaired.
- **CLI Fix:**
  ```ios
  HQ-R1# configure terminal
  HQ-R1(config)# ip access-list standard NAT_INSIDE
  HQ-R1(config-std-nacl)# no permit 10.99.0.0 0.0.0.127
  HQ-R1(config-std-nacl)# permit 10.99.0.0 0.0.0.255
  HQ-R1(config-std-nacl)# end
  HQ-R1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  HQ-R1# show access-lists NAT_INSIDE
  Standard IP access list NAT_INSIDE
      10 permit 10.99.0.0 0.0.0.255

  HQ-R1# show ip nat translations
  Pro  Inside global      Inside local       Outside local      Outside global
  icmp 203.0.113.2:1      10.99.0.130:1      198.51.100.10:1    198.51.100.10:1
  icmp 203.0.113.2:2      10.99.0.162:1      198.51.100.10:1    198.51.100.10:1
  ```

---

### Fault 9 (Hard) - `HQ-R1`: Extended ACL `SERVERS_OUT` Applied in Wrong Direction

- **Device:** `HQ-R1` (`GigabitEthernet0/0.20`)
- **Symptom:** Even after fixing `HQ-SRV1`'s default gateway (Fault 4), Staff PCs (`HQ-PC1`, `BRA-PC1`, `BRB-PC1`) still cannot ping or load HTTP from `HQ-SRV1` (`10.99.0.66`), and `HQ-SRV1` cannot reach any external host. Meanwhile, Guest PCs are not blocked by `SERVERS_OUT` on entry to `G0/0.20` (though `GUEST_IN` blocks them on their own `G0/0.30`).
- **Root Cause:** `interface GigabitEthernet0/0.20` has `ip access-group SERVERS_OUT in` instead of `out`. Every permit ACE in `SERVERS_OUT` matches source = Staff subnets (`10.99.0.0/26`, `.128/27`, `.160/27`) and destination = `HQ-SERVERS` (`10.99.0.64/27`). When applied **inbound** on `G0/0.20`, packets originating from `HQ-SRV1` (`10.99.0.66`) have source `10.99.0.66` and destination = Staff subnet, which fails every permit entry and hits `deny ip any any`, silently dropping all return traffic from `HQ-SRV1`. This fault is partially masked by Fault 4 (`HQ-SRV1` wrong gateway).
- **CLI Fix:**
  ```ios
  HQ-R1# configure terminal
  HQ-R1(config)# interface GigabitEthernet0/0.20
  HQ-R1(config-subif)# no ip access-group SERVERS_OUT in
  HQ-R1(config-subif)# ip access-group SERVERS_OUT out
  HQ-R1(config-subif)# end
  HQ-R1# copy running-config startup-config
  ```
- **Verification Command & Expected Output:**
  ```ios
  HQ-R1# show ip interface GigabitEthernet0/0.20 | include access list
    Outgoing access list is SERVERS_OUT
    Inbound  access list is not set
  ```
  From `HQ-PC1`, `BRA-PC1`, and `BRB-PC1`: `ping 10.99.0.66` succeeds (100%) and browsing `http://10.99.0.66` loads the HTTP page.

---

## Part 3: End-to-End Verification Checklist (Packet Tracer)

After opening `A1_SetA_fixed.pkt` in Cisco Packet Tracer (allow ~30 seconds for STP/OSPF convergence, or click **Fast Forward Time**):

1. **DHCP Leases (All 6 PCs):** Run `ipconfig /renew` (or toggle Static -> DHCP) on `HQ-PC1`, `HQ-PC2`, `BRA-PC1`, `BRA-PC2`, `BRB-PC1`, `BRB-PC2` and verify each receives an IP in its assigned subnet with the correct gateway and DNS `198.51.100.10`.
2. **OSPF Adjacencies & Routes:**
   - `HQ-R1# show ip ospf neighbor` -> `2.2.2.2` (`FULL/-`) on `G0/1`
   - `BRA-R1# show ip ospf neighbor` -> `1.1.1.1` (`FULL/-`) on `G0/1` and `3.3.3.3` (`FULL/-`) on `G0/2`
   - `BRB-R1# show ip ospf neighbor` -> `2.2.2.2` (`FULL/-`) on `G0/1`
   - `BRB-R1# show ip route` -> contains `O*E2 0.0.0.0/0` and all HQ/BRA subnets.
3. **Staff-to-Server & ACL Enforcement:**
   - `HQ-PC1`, `BRA-PC1`, `BRB-PC1` -> `ping 10.99.0.66` and `http://10.99.0.66` **succeed**.
   - `HQ-PC2`, `BRA-PC2`, `BRB-PC2` (Guest) -> `ping 10.99.0.66` and `ping 10.99.0.1` **fail** (blocked by `GUEST_IN`), while `http://www.orbit.test` **succeeds**.
4. **Internet DNS/HTTP & NAT/PAT:**
   - All 6 PCs -> browse `http://www.orbit.test` (`198.51.100.10`) **succeeds**.
   - `HQ-R1# show ip nat translations` -> shows PAT overload translations via `203.0.113.2` for HQ, Branch A, and Branch B hosts.
5. **SSH Hardening (`VTY_ACCESS`):**
   - From `HQ-PC1`, `BRA-PC1`, or `BRB-PC1`: `ssh -l netadmin 10.99.0.1` (password `Secure99pass`) **succeeds**.
   - From any Guest PC: SSH to any router is **blocked**.
