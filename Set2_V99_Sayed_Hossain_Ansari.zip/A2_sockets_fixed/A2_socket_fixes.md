# Assignment 2: Socket Protocol & DNS Proxy Bug-Fixing Lab (`A2_socket_fixes.md`)

**Organization:** Orbit Logistics (`HQ-SRV1` — DNS Resolver Proxy & Two-Stage TCP/UDP Telemetry Server)  
**Deliverables:** Repaired `starter_sockets/` (`dns_proxy.py`, `telemetry_server.py`, `telemetry_client.py`) and `A2_socket_fixes.md`

## Baseline Test Reproduction (`python3 run_socket_tests.py`)

Running the automated test suite against the starter code reproduced all 5 bugs (`0/5` passing):

```text

Orbit Logistics - Assignment 2 Socket Bug-Fixing Test Suite

[FAIL] Bug S1: Byte-Order & Framing -> ValueError: Invalid Type 2 header: msg_type=33554432, msg_len=33554432
[FAIL] Bug S2: Concurrent Server -> AssertionError: Client B blocked waiting for idle Client A (server is not concurrent!)
[FAIL] Bug S3: FIFO Cache & Negative-Hit Poisoning -> AssertionError: Expected 3 upstream queries (cache hits), got 5
[FAIL] Bug S4: CRC-8 Verification & UDP Timeout -> ValueError: Invalid Type 2 header: msg_type=33554432, msg_len=33554432
[FAIL] Bug S5: SO_REUSEADDR, SIGINT & Socket Cleanup -> AssertionError: SO_REUSEADDR is not enabled on TelemetryServer socket
================================================================
RESULT: 0/5 tests passed (0/20 marks)
```

---

## Bug S1: Byte-Order & Framing Bug (4 Marks)

- **Symptom:** During Stage 1 TCP-to-UDP negotiation, `negotiate_udp_port()` fails header validation with `ValueError: Invalid Type 2 header: msg_type=33554432, msg_len=33554432` (and garbles `udp_port`, e.g., `9000` becomes `10275`).
- **How Reproduced:** Ran `python3 run_socket_tests.py` (`test_bug_s1_byte_order`), which connects to `TelemetryServer` over TCP, sends a Type 1 request (`!II`), and unpacks the 10-byte Type 2 reply using network byte order (`!IIH`).
- **Root Cause (`file:line`):** `telemetry_server.py:92` packed the Type 2 response in little-endian (`<IIH`) instead of network byte order / big-endian (`!IIH`):
  ```python
  resp = struct.pack("<IIH", 2, 2, udp_port)
  ```
  When `telemetry_client.py:22` unpacked the bytes with `struct.unpack("!IIH", resp)`, `0x02 0x00 0x00 0x00` was interpreted as `0x02000000 = 33554432` for both `msg_type` and `msg_len`, and the 16-bit `udp_port` bytes were swapped.
- **Fix:** Updated `telemetry_server.py:92` to pack the Type 2 response in network byte order (`!IIH`):
  ```python
  resp = struct.pack("!IIH", 2, 2, udp_port)
  ```
- **Verification Output:**
  ```text
  [PASS] Bug S1: Byte-Order & Framing (4/4 marks)
  ```

---

## Bug S2: Non-Concurrent Blocking Server (4 Marks)

- **Symptom:** When Client A opens a TCP connection to `DNSProxyServer` (or `TelemetryServer`) and stalls without sending data, Client B blocks until Client A disconnects or times out.
- **How Reproduced:** Ran `python3 run_socket_tests.py` (`test_bug_s2_concurrency`), which opens an idle TCP socket (`blocker`) to `DNSProxyServer` and then runs `query_dns_proxy()` from Client B in a separate thread with a `1.2s` join timeout; the test failed with `AssertionError: Client B blocked waiting for idle Client A (server is not concurrent!)`.
- **Root Cause (`file:line`):**
  - `dns_proxy.py:55`: `self._handle_client(conn)` was invoked synchronously inside `_serve()`'s `accept()` loop, blocking all subsequent clients while `recv_exact()` waited on Client A.
  - `telemetry_server.py:73`: `self._handle_tcp_negotiation(conn)` was likewise called synchronously inside `_serve()`.
- **Fix:** Spawned a daemon worker thread per accepted TCP connection in both servers:
  - `dns_proxy.py:55`:
    ```python
    threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()
    ```
  - `telemetry_server.py:73`:
    ```python
    threading.Thread(target=self._handle_tcp_negotiation, args=(conn,), daemon=True).start()
    ```
- **Verification Output:**
  ```text
  [PASS] Bug S2: Concurrent Server (4/4 marks)
  ```

---

## Bug S3: Broken FIFO Cache & Negative-Hit Error Poisoning (4 Marks)

- **Symptom:** (a) Only the most recently queried domain remained cached (upstream received 5 queries instead of 3 when re-querying the first two entries of a 3-entry cache); (b) querying a nonexistent domain (`ghost.orbit.test`) cached the Type 4 error response and returned it on the second query as a Type 3 valid hit (`(3, "entry not found in the database")`).
- **How Reproduced:** Ran `python3 run_socket_tests.py` (`test_bug_s3_fifo_cache_and_negative_hit`), which queries 3 valid domains, re-queries the first two, queries a 4th domain to test FIFO eviction of slot 0, and queries `ghost.orbit.test` twice; failed with `AssertionError: Expected 3 upstream queries (cache hits), got 5`.
- **Root Cause (`file:line`):** `dns_proxy.py:64-69` in `_update_cache()`:
  - Lines 66–69 only appended when `len(self.cache) == 0` and otherwise overwrote `self.cache[0]`, capping the cache at 1 entry instead of maintaining `CACHE_CAPACITY = 3` entries with FIFO eviction (`pop(0)`).
  - `_update_cache()` ignored `resp_type` and cached Type 4 error responses; `_handle_client()` (`dns_proxy.py:95-97`) unconditionally returned cached entries with `resp_type = 3`, poisoning subsequent lookups.
- **Fix:** Updated `_update_cache()` in `dns_proxy.py:64-73` to cache only `resp_type == 3` responses and perform 3-entry FIFO eviction:
  ```python
  def _update_cache(self, req_type, query, resp_type, resp_msg):
      if resp_type != 3:
          return
      with self._lock:
          for rtype, q, _ in self.cache:
              if rtype == req_type and q == query:
                  return
          if len(self.cache) >= self.CACHE_CAPACITY:
              self.cache.pop(0)
          self.cache.append((req_type, query, resp_msg))
  ```
- **Verification Output:**
  ```text
  [PASS] Bug S3: FIFO Cache & Negative-Hit Poisoning (4/4 marks)
  ```

---

## Bug S4: Inverted CRC-8 Check & Missing UDP Receive Timeout (4 Marks)

- **Symptom:** (a) `TelemetryServer` sent `ACK` on corrupted frames (`remainder != 0`) and `NACK` on valid frames (`remainder == 0`), accepting corrupted payloads; (b) when the first `ACK` was dropped on the wire (`drop_first_ack=True`), `send_telemetry_udp()` hung forever waiting in `recvfrom()` instead of timing out and retransmitting.
- **How Reproduced:** Ran `python3 run_socket_tests.py` (`test_bug_s4_crc8_and_udp_timeout`), which tests (Part A) sending a bit-flipped frame (`corrupt_first=True`) and asserting `NACK` followed by `ACK` on attempt 2, and (Part B) dropping the first `ACK` (`drop_first_ack=True`) and asserting retransmission succeeds within `2.0s`.
- **Root Cause (`file:line`):**
  - `telemetry_server.py:114`: `if remainder != 0:` inverted the CRC-8 divisibility check. Because `build_crc8_frame()` appends the 1-byte remainder for `G(x) = x^8 + x^2 + x + 1`, an uncorrupted frame satisfies `compute_crc8(frame) == 0`.
  - `telemetry_client.py:34`: `udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)` had no receive timeout (`settimeout()` was never called), so `udp_sock.recvfrom(1024)` at line 45 blocked indefinitely on packet loss instead of raising `socket.timeout` for the `except socket.timeout:` retry handler at line 46.
- **Fix:**
  - `telemetry_server.py:114`: Changed `if remainder != 0:` to `if remainder == 0:`.
  - `telemetry_client.py:35`: Added `udp_sock.settimeout(0.5)` immediately after creating `udp_sock`.
- **Verification Output:**
  ```text
  [PASS] Bug S4: CRC-8 Verification & UDP Timeout (4/4 marks)
  ```

---

## Bug S5: Missing `SO_REUSEADDR`, Missing `SIGINT` Handler & TCP Socket Leak (4 Marks)

- **Symptom:** Server sockets lacked `SO_REUSEADDR` (risking `EADDRINUSE` on restart), `register_signal_handlers()` did not register a `SIGINT` handler, and Stage 1 TCP negotiation sockets were never closed (leaking file descriptors on every client negotiation).
- **How Reproduced:** Ran `python3 run_socket_tests.py` (`test_bug_s5_reuseaddr_sigint_and_socket_cleanup`), which checks `getsockopt(SOL_SOCKET, SO_REUSEADDR)`, `srv.sigint_handler_registered`, and `len(srv.leaked_tcp_sockets) == 0` after a negotiation; failed with `AssertionError: SO_REUSEADDR is not enabled on TelemetryServer socket`.
- **Root Cause (`file:line`):**
  - `telemetry_server.py:56` and `dns_proxy.py:38`: `setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)` was omitted prior to `bind()`.
  - `telemetry_server.py:52-53`: `register_signal_handlers()` was an empty `pass` stub, leaving `self.sigint_handler_registered = False` and registering no `signal.SIGINT` handler (`dns_proxy.py` `__main__` also omitted `signal.signal(signal.SIGINT, ...)`).
  - `telemetry_server.py:75-95`: `_handle_tcp_negotiation()` appended `conn` to `self.leaked_tcp_sockets` instead of closing `conn` in a `finally:` block.
- **Fix:**
  - `telemetry_server.py:52-54`: Registered `signal.signal(signal.SIGINT, lambda *_: self.stop())` and set `self.sigint_handler_registered = True`.
  - `telemetry_server.py:57` and `dns_proxy.py:39`: Added `self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)` before `bind()`.
  - `telemetry_server.py:75-99`: Wrapped `_handle_tcp_negotiation()` in `try: ... finally: conn.close()` and removed `self.leaked_tcp_sockets.append(conn)`.
  - `dns_proxy.py:139`: Added `signal.signal(signal.SIGINT, lambda *_: srv.stop())` in `__main__`.
- **Verification Output:**
  ```text
  [PASS] Bug S5: SO_REUSEADDR, SIGINT & Socket Cleanup (4/4 marks)
  ```

---

## Final Verification Suite Output

```text
 python3 run_socket_tests.py

Orbit Logistics - Assignment 2 Socket Bug-Fixing Test Suite

[PASS] Bug S1: Byte-Order & Framing (4/4 marks)
[PASS] Bug S2: Concurrent Server (4/4 marks)
[PASS] Bug S3: FIFO Cache & Negative-Hit Poisoning (4/4 marks)
[PASS] Bug S4: CRC-8 Verification & UDP Timeout (4/4 marks)
[PASS] Bug S5: SO_REUSEADDR, SIGINT & Socket Cleanup (4/4 marks)

```
