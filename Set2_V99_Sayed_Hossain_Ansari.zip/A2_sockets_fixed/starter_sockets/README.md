# Assignment 2: Socket Protocol & DNS Proxy Bug-Fixing Lab

## Overview
This folder contains Orbit Logistics' multi-stage **DNS Resolver Proxy** and **Two-Stage TCP/UDP Telemetry Server**:

- `dns_db.txt` — Upstream DNS database (`<domain> <ip>`).
- `dns_server.py` — Upstream TCP DNS server (working reference; do not break).
- `dns_proxy.py` — Stage 1 TCP DNS Proxy with a 3-entry FIFO cache.
- `telemetry_server.py` — Stage 2 TCP-to-UDP negotiation server + CRC-8 UDP receiver.
- `telemetry_client.py` — Stage 2 client with CRC-8 framing and Stop-and-Wait retransmission.
- `run_socket_tests.py` — Automated test suite that tests all 5 injected bugs (`Bug S1` to `Bug S5`).

## How to Run Tests
```bash
python run_socket_tests.py
```

## Your Task
1. Run `python run_socket_tests.py` to reproduce all 5 bugs.
2. Fix the root causes in `dns_proxy.py`, `telemetry_server.py`, and `telemetry_client.py` so all 5 tests pass (`5/5 PASS`).
3. Document each bug in `A2_socket_fixes.md` using the format:
   `Symptom -> How You Reproduced It -> Root Cause (file:line) -> Fix -> Verification Output`.
