import signal
import socket
import struct
import sys
import threading


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


class DNSProxyServer:
    """
    Stage 1: Multi-stage TCP DNS Proxy with a 3-entry FIFO cache.
    Request format:  !II + utf8 query  (req_type: 1=Domain->IP, 2=IP->Domain)
    Response format: !II + utf8 result (resp_type: 3=Found, 4=Error)
    """

    CACHE_CAPACITY = 3

    def __init__(self, host="127.0.0.1", port=0, upstream_host="127.0.0.1", upstream_port=5353):
        self.host = host
        self.port = port
        self.upstream_host = upstream_host
        self.upstream_port = upstream_port
        self.cache = []  # List of (req_type, query, result) tuples, max 3 entries (FIFO)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.sock = None

    def start(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.port = self.sock.getsockname()[1]
        self.sock.listen(16)
        self.sock.settimeout(0.2)
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        return self.port

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()

    def _lookup_cache(self, req_type, query):
        with self._lock:
            for rtype, q, val in self.cache:
                if rtype == req_type and q == query:
                    return val
        return None

    def _update_cache(self, req_type, query, resp_type, resp_msg):
        if resp_type != 3:
            return
        with self._lock:
            for rtype, q, _ in self.cache:
                if rtype == req_type and q == query:
                    return
            if len(self.cache) >= self.CACHE_CAPACITY:
                self.cache.pop(0)
            self.cache.append((req_type, query, resp_msg))

    def _query_upstream(self, req_type, query):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2.0)
            s.connect((self.upstream_host, self.upstream_port))
            q_bytes = query.encode("utf-8")
            s.sendall(struct.pack("!II", req_type, len(q_bytes)) + q_bytes)
            header = recv_exact(s, 8)
            if not header:
                return 4, "upstream closed"
            resp_type, resp_len = struct.unpack("!II", header)
            payload = recv_exact(s, resp_len)
            return resp_type, payload.decode("utf-8")

    def _handle_client(self, conn):
        try:
            header = recv_exact(conn, 8)
            if not header:
                return
            req_type, msg_len = struct.unpack("!II", header)
            payload = recv_exact(conn, msg_len)
            if payload is None:
                return
            query = payload.decode("utf-8")

            cached = self._lookup_cache(req_type, query)
            if cached is not None:
                resp_type, resp_msg = 3, cached
            else:
                resp_type, resp_msg = self._query_upstream(req_type, query)
                self._update_cache(req_type, query, resp_type, resp_msg)

            resp_bytes = resp_msg.encode("utf-8")
            conn.sendall(struct.pack("!II", resp_type, len(resp_bytes)) + resp_bytes)
        finally:
            conn.close()

    def stop(self):
        self._stop.set()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass


def query_dns_proxy(host, port, req_type, query):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(2.0)
        s.connect((host, port))
        q_bytes = query.encode("utf-8")
        s.sendall(struct.pack("!II", req_type, len(q_bytes)) + q_bytes)
        header = recv_exact(s, 8)
        resp_type, resp_len = struct.unpack("!II", header)
        payload = recv_exact(s, resp_len)
        return resp_type, payload.decode("utf-8")


if __name__ == "__main__":
    proxy_port = int(sys.argv[1]) if len(sys.argv) > 1 else 5354
    upstream_port = int(sys.argv[2]) if len(sys.argv) > 2 else 5353
    srv = DNSProxyServer(port=proxy_port, upstream_port=upstream_port)
    actual_port = srv.start()
    print(f"DNS Proxy listening on 127.0.0.1:{actual_port} (upstream :{upstream_port})")
    signal.signal(signal.SIGINT, lambda *_: srv.stop())
    try:
        while not srv._stop.is_set():
            srv._stop.wait(0.5)
    finally:
        srv.stop()
