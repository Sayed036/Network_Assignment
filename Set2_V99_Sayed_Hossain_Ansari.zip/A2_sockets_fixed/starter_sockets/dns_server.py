import os
import signal
import socket
import struct
import sys
import threading


def load_db(db_path):
    forward = {}
    reverse = {}
    with open(db_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                domain, ip = parts[0], parts[1]
                forward[domain] = ip
                reverse[ip] = domain
    return forward, reverse


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


class UpstreamDNSServer:
    def __init__(self, host="127.0.0.1", port=0, db_path=None):
        self.host = host
        self.port = port
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), "dns_db.txt")
        self.forward, self.reverse = load_db(db_path)
        self.query_count = 0
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.sock = None

    def start(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.port = self.sock.getsockname()[1]
        self.sock.listen(16)
        self.sock.settimeout(0.2)
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        return self.port

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()

    def _handle_client(self, conn):
        try:
            header = recv_exact(conn, 8)
            if not header:
                return
            req_type, msg_len = struct.unpack("!II", header)
            payload = recv_exact(conn, msg_len)
            if payload is None:
                return
            query = payload.decode("utf-8")
            with self._lock:
                self.query_count += 1
            if req_type == 1 and query in self.forward:
                resp_type, resp_msg = 3, self.forward[query]
            elif req_type == 2 and query in self.reverse:
                resp_type, resp_msg = 3, self.reverse[query]
            else:
                resp_type, resp_msg = 4, "entry not found in the database"
            resp_bytes = resp_msg.encode("utf-8")
            conn.sendall(struct.pack("!II", resp_type, len(resp_bytes)) + resp_bytes)
        finally:
            conn.close()

    def stop(self):
        self._stop.set()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5353
    srv = UpstreamDNSServer(port=port)
    actual_port = srv.start()
    print(f"Upstream DNS Server listening on 127.0.0.1:{actual_port}")
    signal.signal(signal.SIGINT, lambda *_: srv.stop())
    try:
        while not srv._stop.is_set():
            srv._stop.wait(0.5)
    finally:
        srv.stop()
