import socket
import sys
import threading
import time

from dns_server import UpstreamDNSServer
from dns_proxy import DNSProxyServer, query_dns_proxy
from telemetry_server import TelemetryServer
from telemetry_client import negotiate_udp_port, send_telemetry_udp


def test_bug_s1_byte_order():
    """Bug S1: TCP -> UDP negotiation must use network byte order (!IIH)."""
    srv = TelemetryServer()
    tcp_port = srv.start()
    try:
        udp_port = negotiate_udp_port("127.0.0.1", tcp_port)
        assert 1024 <= udp_port <= 65535, f"Unexpected negotiated UDP port: {udp_port}"
    finally:
        srv.stop()


def test_bug_s2_concurrency():
    """Bug S2: Server must serve Client B concurrently while Client A holds a connection open."""
    upstream = UpstreamDNSServer()
    up_port = upstream.start()
    proxy = DNSProxyServer(upstream_port=up_port)
    proxy_port = proxy.start()
    blocker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # Client A opens TCP connection and stalls without sending data
        blocker.connect(("127.0.0.1", proxy_port))
        time.sleep(0.1)

        # Client B must still get a fast response concurrently!
        result = {}
        def client_b():
            try:
                result["resp"] = query_dns_proxy("127.0.0.1", proxy_port, 1, "www.orbit.test")
            except Exception as e:
                result["err"] = e

        t = threading.Thread(target=client_b, daemon=True)
        t.start()
        t.join(timeout=1.2)
        assert not t.is_alive(), "Client B blocked waiting for idle Client A (server is not concurrent!)"
        assert "resp" in result and result["resp"] == (3, "198.51.100.10"), f"Unexpected Client B result: {result}"
    finally:
        blocker.close()
        proxy.stop()
        upstream.stop()


def test_bug_s3_fifo_cache_and_negative_hit():
    """Bug S3: 3-entry FIFO cache eviction + never cache Type 4 error responses."""
    upstream = UpstreamDNSServer()
    up_port = upstream.start()
    proxy = DNSProxyServer(upstream_port=up_port)
    proxy_port = proxy.start()
    try:
        # 1) Query 3 valid domains to fill the 3-entry FIFO cache
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "www.orbit.test") == (3, "198.51.100.10")
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "hq-srv1.orbit.lab") == (3, "10.99.0.66")
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "bra-r1.orbit.lab") == (3, "10.99.0.129")
        assert upstream.query_count == 3

        # All 3 should now be cache hits (upstream count stays 3)
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "www.orbit.test") == (3, "198.51.100.10")
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "hq-srv1.orbit.lab") == (3, "10.99.0.66")
        assert upstream.query_count == 3, f"Expected 3 upstream queries (cache hits), got {upstream.query_count}"

        # 2) Query a 4th domain -> should evict oldest ('www.orbit.test') in FIFO order, keeping 2nd & 3rd
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "brb-r1.orbit.lab") == (3, "10.99.0.161")
        assert upstream.query_count == 4
        assert query_dns_proxy("127.0.0.1", proxy_port, 1, "hq-srv1.orbit.lab") == (3, "10.99.0.66")
        assert upstream.query_count == 4, "FIFO eviction failed: 2nd entry was evicted prematurely"

        # 3) Query an unknown domain twice -> MUST return Type 4 both times (never cached as Type 3!)
        r1 = query_dns_proxy("127.0.0.1", proxy_port, 1, "ghost.orbit.test")
        r2 = query_dns_proxy("127.0.0.1", proxy_port, 1, "ghost.orbit.test")
        assert r1[0] == 4 and r2[0] == 4, f"Negative-hit cache poisoning detected: r1={r1}, r2={r2}"
    finally:
        proxy.stop()
        upstream.stop()


def test_bug_s4_crc8_and_udp_timeout():
    """Bug S4: Server rejects corrupted CRC-8 frame with NACK, accepts clean retransmit; client times out on dropped ACK."""
    # Part A: Corrupted first frame -> server must send NACK -> client retries and succeeds on attempt 2
    srv = TelemetryServer(drop_first_ack=False)
    tcp_port = srv.start()
    try:
        udp_port = negotiate_udp_port("127.0.0.1", tcp_port)
        ok, attempts = send_telemetry_udp("127.0.0.1", udp_port, "telemetry:cpu=42%", corrupt_first=True)
        assert ok and attempts == 2, f"Expected ACK on attempt 2 after NACK, got ok={ok}, attempts={attempts}"
        assert srv.received_messages == ["telemetry:cpu=42%"], f"Corrupted message accepted: {srv.received_messages}"
    finally:
        srv.stop()

    # Part B: Dropped first ACK -> client UDP socket must time out and retransmit (not hang forever!)
    srv2 = TelemetryServer(drop_first_ack=True)
    tcp_port2 = srv2.start()
    outcome = {}
    def run_client():
        try:
            uport = negotiate_udp_port("127.0.0.1", tcp_port2)
            outcome["res"] = send_telemetry_udp("127.0.0.1", uport, "telemetry:mem=61%", corrupt_first=False)
        except Exception as e:
            outcome["err"] = e

    t = threading.Thread(target=run_client, daemon=True)
    t.start()
    t.join(timeout=2.0)
    srv2.stop()
    assert not t.is_alive(), "Client hung forever on dropped ACK (missing UDP receive timeout!)"
    assert outcome.get("res") == (True, 2), f"Expected timeout + retransmit ACK on attempt 2, got {outcome}"


def test_bug_s5_reuseaddr_sigint_and_socket_cleanup():
    """Bug S5: SO_REUSEADDR enabled, SIGINT handler registered, and Stage 1 TCP socket closed cleanly."""
    srv = TelemetryServer()
    srv.register_signal_handlers()
    tcp_port = srv.start()
    try:
        reuse = srv.sock.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR)
        assert reuse != 0, "SO_REUSEADDR is not enabled on TelemetryServer socket"
        assert srv.sigint_handler_registered, "SIGINT handler not registered in register_signal_handlers()"

        _ = negotiate_udp_port("127.0.0.1", tcp_port)
        time.sleep(0.1)
        assert len(srv.leaked_tcp_sockets) == 0, f"Stage 1 TCP sockets leaked: {len(srv.leaked_tcp_sockets)} unclosed"
    finally:
        srv.stop()


def main():
    tests = [
        ("Bug S1: Byte-Order & Framing", test_bug_s1_byte_order),
        ("Bug S2: Concurrent Server", test_bug_s2_concurrency),
        ("Bug S3: FIFO Cache & Negative-Hit Poisoning", test_bug_s3_fifo_cache_and_negative_hit),
        ("Bug S4: CRC-8 Verification & UDP Timeout", test_bug_s4_crc8_and_udp_timeout),
        ("Bug S5: SO_REUSEADDR, SIGINT & Socket Cleanup", test_bug_s5_reuseaddr_sigint_and_socket_cleanup),
    ]
    passed = 0
    print("=" * 64)
    print("Orbit Logistics — Assignment 2 Socket Bug-Fixing Test Suite")
    print("=" * 64)
    for name, fn in tests:
        try:
            fn()
            print(f"[PASS] {name} (4/4 marks)")
            passed += 1
        except Exception as e:
            print(f"[FAIL] {name} -> {type(e).__name__}: {e}")
    print("=" * 64)
    print(f"RESULT: {passed}/{len(tests)} tests passed ({passed * 4}/20 marks)")
    sys.exit(0 if passed == len(tests) else 1)


if __name__ == "__main__":
    main()
