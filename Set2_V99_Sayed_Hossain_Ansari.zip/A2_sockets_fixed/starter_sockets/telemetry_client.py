import socket
import struct
from telemetry_server import compute_crc8, recv_exact


def build_crc8_frame(message: str) -> bytes:
    """Append 1-byte CRC-8 checksum so compute_crc8(frame) == 0."""
    raw = message.encode("utf-8")
    checksum = compute_crc8(raw)
    return raw + bytes([checksum])


def negotiate_udp_port(host: str, tcp_port: int):
    """Stage 1: Connect over TCP, send Type 1, receive Type 2 with UDP port, close TCP."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tcp_sock:
        tcp_sock.settimeout(2.0)
        tcp_sock.connect((host, tcp_port))
        tcp_sock.sendall(struct.pack("!II", 1, 0))
        resp = recv_exact(tcp_sock, 10)
        if not resp:
            raise RuntimeError("No Type 2 response from server")
        msg_type, msg_len, udp_port = struct.unpack("!IIH", resp)
        if msg_type != 2 or msg_len != 2:
            raise ValueError(f"Invalid Type 2 header: msg_type={msg_type}, msg_len={msg_len}")
        return udp_port


def send_telemetry_udp(host: str, udp_port: int, message: str, corrupt_first: bool = False, max_retries: int = 4):
    """
    Stage 2: Transmit Type 3 UDP frame with CRC-8 and Stop-and-Wait retransmission.
    Returns (ack_received: bool, attempts: int).
    """
    frame = build_crc8_frame(message)
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.settimeout(0.5)
    attempts = 0
    try:
        for attempt in range(1, max_retries + 1):
            attempts = attempt
            tx_frame = bytearray(frame)
            if corrupt_first and attempt == 1:
                tx_frame[0] ^= 0xFF  # Inject bit error on first attempt
            packet = struct.pack("!II", 3, len(tx_frame)) + bytes(tx_frame)
            udp_sock.sendto(packet, (host, udp_port))
            try:
                reply, _ = udp_sock.recvfrom(1024)
            except socket.timeout:
                continue  # Retransmit on timeout
            if len(reply) >= 4:
                rtype = struct.unpack("!I", reply[:4])[0]
                status = reply[4:]
                if rtype == 4 and status == b"ACK":
                    return True, attempts
        return False, attempts
    finally:
        udp_sock.close()
