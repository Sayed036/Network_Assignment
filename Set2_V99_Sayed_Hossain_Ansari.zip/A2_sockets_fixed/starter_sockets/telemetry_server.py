import signal
import socket
import struct
import sys
import threading

CRC8_POLY = 0x07  # G(x) = x^8 + x^2 + x + 1


def compute_crc8(data: bytes) -> int:
    """Compute CRC-8 remainder using generator polynomial G(x) = x^8 + x^2 + x + 1."""
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ CRC8_POLY) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


class TelemetryServer:
    """
    Stage 2: Two-stage TCP Negotiation -> UDP Data Transfer with CRC-8.
    - TCP Type 1 Request:  !II   (msg_type=1, msg_len=0)
    - TCP Type 2 Response: !IIH  (msg_type=2, msg_len=2, udp_port)
    - UDP Type 3 Data:     !II + payload_bytes + 1-byte CRC8
    - UDP Type 4 Reply:    !I + b"ACK" or b"NACK"
    """

    def __init__(self, host="127.0.0.1", port=0, drop_first_ack=False):
        self.host = host
        self.port = port
        self.drop_first_ack = drop_first_ack
        self.received_messages = []
        self.leaked_tcp_sockets = []
        self.sigint_handler_registered = False
        self._stop = threading.Event()
        self.sock = None

    def register_signal_handlers(self):
        signal.signal(signal.SIGINT, lambda *_: self.stop())
        self.sigint_handler_registered = True

    def start(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.port = self.sock.getsockname()[1]
        self.sock.listen(16)
        self.sock.settimeout(0.2)
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        return self.port

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle_tcp_negotiation, args=(conn,), daemon=True).start()

    def _handle_tcp_negotiation(self, conn):
        try:
            conn.settimeout(5.0)
            header = recv_exact(conn, 8)
            if not header:
                return
            msg_type, msg_len = struct.unpack("!II", header)
            if msg_type != 1:
                return

            # Allocate ephemeral UDP socket for Stage 2
            udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            udp_sock.bind((self.host, 0))
            udp_port = udp_sock.getsockname()[1]

            # Start UDP listener for this client session
            threading.Thread(target=self._handle_udp_transfer, args=(udp_sock,), daemon=True).start()

            resp = struct.pack("!IIH", 2, 2, udp_port)
            conn.sendall(resp)
        finally:
            conn.close()

    def _handle_udp_transfer(self, udp_sock):
        udp_sock.settimeout(3.0)
        dropped_once = False
        try:
            while not self._stop.is_set():
                try:
                    packet, client_addr = udp_sock.recvfrom(4096)
                except socket.timeout:
                    break
                if len(packet) < 9:
                    continue
                msg_type, msg_len = struct.unpack("!II", packet[:8])
                if msg_type != 3:
                    continue
                frame = packet[8:8 + msg_len]  # payload + 1-byte CRC8

                remainder = compute_crc8(frame)
                if remainder == 0:
                    if self.drop_first_ack and not dropped_once:
                        dropped_once = True
                        continue  # simulate dropped ACK on the wire
                    self.received_messages.append(frame[:-1].decode("utf-8", errors="replace"))
                    udp_sock.sendto(struct.pack("!I", 4) + b"ACK", client_addr)
                    break
                else:
                    udp_sock.sendto(struct.pack("!I", 4) + b"NACK", client_addr)
        finally:
            udp_sock.close()

    def stop(self):
        self._stop.set()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        for s in self.leaked_tcp_sockets:
            try:
                s.close()
            except OSError:
                pass


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
    srv = TelemetryServer(port=port)
    srv.register_signal_handlers()
    actual_port = srv.start()
    print(f"Telemetry Server listening on 127.0.0.1:{actual_port}")
    try:
        while not srv._stop.is_set():
            srv._stop.wait(0.5)
    finally:
        srv.stop()
