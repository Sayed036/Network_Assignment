# Assignment 3: PCAP Telemetry & Traffic Diagnostic Report (`A3_traffic_report.md`)

**Host Analyzed:** `BRB-PC1` (`10.99.0.162/27`, Branch B)  
**Inputs:** `orbit_incident.pcap` (130,062 packets, 184,694,280 bytes, 20.00 s capture) and `ping_traceroute_logs.txt`  
**Deliverables:** `speedtest_analysis.py`, `throughput_timeseries.png`, and `A3_traffic_report.md`

---

## Task 1: `speedtest_analysis.py` Bug Fixes & Verification (9 Marks)

### Summary of Repaired Bugs

| Bug ID | Root Cause (`file:line` in starter) | Fix Applied |
|---|---|---|
| **Bug P1 (Flow Isolation)** | `speedtest_analysis.py:52` summed `orig_len` for *every* packet in the PCAP (mixing TURN video/audio, HTTP, DNS, and ICMP into `ndt_bytes`, reporting `100.0%`). | Filtered strictly to TCP (`proto == 6`) packets between `CLIENT_IP` (`10.99.0.162`) and `NDT7_SERVER_IP` (`198.51.100.50`) on TCP port `3001`. |
| **Bug P2 (Direction & Mbps Conversion)** | `speedtest_analysis.py:54-63, 81-82` swapped downlink and uplink (`src_ip == CLIENT_IP` counted as downlink), omitted `* 8.0` (computing MB/s instead of Mbps), and divided by `total_duration` (`20.00 s`) instead of each phase's active transfer window (`10.00 s` each). | Assigned `198.51.100.50:3001 -> 10.99.0.162` to downlink and `10.99.0.162 -> 198.51.100.50:3001` to uplink; computed `(bytes * 8.0 / 1_000_000.0) / phase_duration` over each phase's `[min(ts), max(ts)]` active window and applied `* 8.0 / 1_000_000.0` in `save_plot()`. |
| **Bug P3 (Time-Series Binning in `--plot`)** | `speedtest_analysis.py:53` binned packets using `int(ts) % 10`, folding seconds `10–19` (uplink) on top of seconds `0–9` (downlink). | Captured `t0` (first packet timestamp) and binned into 1-second relative buckets `int(ts - t0)` across the full 20-second timeline. |

### Verification Output (`--throughput --plot`)

- **Before (Buggy Starter):** `2.90,6.33` (`Speedtest traffic share: 100.0%`)
- **After (Repaired):**
  ```text
  $ python3 speedtest_analysis.py orbit_incident.pcap --throughput --plot
  84.60,31.25
  Speedtest traffic share: 78.4%
  Saved plot to throughput_timeseries.png
  ```
- **Breakdown of `orbit_incident.pcap` Flows:**

| Flow | Protocol & Endpoints | Packets | Total Bytes (`orig_len`) | Share of Capture | Active Window | Mean Rate |
|---|---|---:|---:|---:|---|---:|
| NDT7 Downlink | TCP `198.51.100.50:3001 -> 10.99.0.162:51234` | 70,500 | 105,750,000 B | 57.26% | 0.00 – 10.00 s (10.00 s) | **84.60 Mbps** |
| NDT7 Uplink | TCP `10.99.0.162:51234 -> 198.51.100.50:3001` | 26,042 | 39,063,000 B | 21.15% | 10.00 – 20.00 s (10.00 s) | **31.25 Mbps** |
| **NDT7 Combined** | **TCP Port `3001`** | **96,542** | **144,813,000 B** | **78.41%** | **0.00 – 20.00 s** | — |
| Media Video (DL + UL) | UDP `10.99.0.162:50006 <-> 198.51.100.200:3478` | 30,000 | 37,500,000 B | 20.30% | 0.00 – 20.00 s (20.00 s) | 7.50 Mbps / dir |
| Media Audio (DL + UL) | UDP `10.99.0.162:50004 <-> 198.51.100.200:3478` | 2,000 | 388,000 B | 0.21% | 0.00 – 19.98 s (19.98 s) | 77.6 kbps / dir |
| Background HTTP | TCP `198.51.100.80:80 -> 10.99.0.162:52010` | 1,400 | 1,979,600 B | 1.07% | 0.00 – 19.99 s | 0.79 Mbps |
| Background DNS | UDP `10.99.0.162:54001 <-> 198.51.100.10:53` | 80 | 9,760 B | 0.01% | 0.00 – 19.51 s | — |
| Background ICMP | ICMP `10.99.0.162 <-> 198.51.100.10` | 40 | 3,920 B | 0.00% | 0.00 – 19.02 s | — |
| **Total Capture** | **All Flows** | **130,062** | **184,694,280 B** | **100.00%** | **20.00 s** | — |

---

## Task 2: Diagnostic Questions (6 Marks, 2 Marks Each)

### 1. Ping MTU & IPv6 Diagnostics (2 Marks)

- **Why `ping -s 1472 -M do` succeeds while `ping -s 1480 -M do` fails on Ethernet (MTU 1500):**
  - Standard Ethernet has an L3 Maximum Transmission Unit (MTU) of **1,500 bytes** (the maximum IPv4 packet size excluding the 14-byte Ethernet header and 4-byte FCS).
  - An ICMP Echo Request carries a **20-byte IPv4 header** (without options) plus an **8-byte ICMP header** = **28 bytes** of header overhead.
  - With `-s 1472`: `1,472 (payload) + 8 (ICMP) + 20 (IPv4) = 1,500 bytes <= 1,500 MTU`, so the packet fits inside a single Ethernet frame without fragmentation and succeeds (`0%` loss in `ping_traceroute_logs.txt`).
  - With `-s 1480 -M do`: `1,480 + 8 + 20 = 1,508 bytes > 1,500 MTU`. Because `-M do` sets the IPv4 **Don't Fragment (DF)** flag, the local kernel refuses to fragment the packet and immediately returns `ping: local error: message too long, mtu=1500` (`100%` loss).
- **Comparison with Theoretical Maximum ICMP Payload Size (65,507 B):**
  - The IPv4 **Total Length** field is 16 bits, giving a theoretical maximum IPv4 datagram size of `2^16 - 1 = 65,535 bytes`.
  - Subtracting the 20-byte IPv4 header and 8-byte ICMP header leaves a theoretical maximum ICMP payload of `65,535 - 20 - 8 = 65,507 bytes`.
  - A 65,507-byte ICMP payload can only be transmitted over Ethernet if **IP fragmentation is allowed** (i.e., DF bit = 0), splitting the datagram into ~45 Ethernet-sized fragments (`1,480` bytes of IP payload per fragment, since fragment offsets are multiples of 8 bytes). With `-M do` (DF = 1), the practical unfragmented limit is capped by the Path MTU (`1,472` bytes on 1500-byte Ethernet).
- **Why `ping -6 -c 4 google.com` failed on Branch B (`BRB-PC1`):**
  - From `ip addr show eth0` in `ping_traceroute_logs.txt`, `BRB-PC1` only has a **link-local IPv6 address** (`fe80::211:22ff:fe33:4455/64 scope link`) and **no global unicast IPv6 address (`2000::/3`) or IPv6 default route**.
  - Link-local addresses (`fe80::/10`) are non-routable beyond the local Layer 2 broadcast domain, and Orbit Logistics' routers (`BRB-R1`, `BRA-R1`, `HQ-R1`, `ISP-R1`) are configured as IPv4-only (`no ipv6 cef`, no IPv6 addresses/routing). Therefore, the OS kernel immediately rejects the socket connection with `ping: connect: Network is unreachable`.

### 2. Traceroute Anomalies (2 Marks)

- **Why Hop 4 shows `* * *` while Hops 5–11 succeed:**
  - `traceroute` works by sending probes with incrementing IPv4 TTLs (`1, 2, 3, ...`) and listening for **ICMP Time Exceeded (Type 11, Code 0)** replies from each router where TTL decrements to 0.
  - Hop 4 (the ISP edge router immediately past `HQ-R1` at Hop 3 `10.99.0.225`) still **forwards** packets normally in the data plane (which is why Hops 5–11 succeed all the way to `sigcomm.org` `128.112.136.61`), but its control plane **drops or rate-limits outbound ICMP Time Exceeded messages** (or filters traceroute probes via an ACL/firewall policy). Because no ICMP reply arrives within the probe timeout, `traceroute` prints `* * *` for all three probes at TTL = 4.
- **Why Hop 6 shows 3 distinct IPs (`198.18.4.1`, `198.18.4.5`, `198.18.4.9`):**
  - Hop 5 (`203.0.113.5`) is performing **Equal-Cost Multi-Path (ECMP)** load balancing across three equal-cost next-hop routers/links at Hop 6.
  - Classic UDP `traceroute` increments the destination UDP port (e.g., `33434`, `33435`, `33436`) for each of the 3 probes at TTL = 6. Because per-flow ECMP hashes the 5-tuple `(src IP, dst IP, protocol, src port, dst port)`, each probe hashes to a different ECMP path and elicits an ICMP Time Exceeded reply from a different router interface (`198.18.4.1`, `198.18.4.5`, and `198.18.4.9`).
- **Whether pinging private first-hop `10.99.0.1` from cellular data can succeed:**
  - **No** (confirmed by `100% packet loss` in Section 4 of `ping_traceroute_logs.txt`).
  - `10.99.0.1` is an **RFC 1918 private IPv4 address** (`10.0.0.0/8`), which is **not globally routable** on the public Internet; carrier/ISP routers drop or blackhole packets destined for RFC 1918 space (or route them internally inside the carrier's own private network, never reaching Orbit Logistics' HQ LAN).
  - Furthermore, Orbit Logistics' internal network sits behind **PAT/NAT overload** on `HQ-R1 G0/2` (`203.0.113.2`), so unsolicited inbound packets from the public Internet have no translation state and cannot reach `10.99.0.1` without an explicit VPN tunnel or static NAT/port-forwarding rule.

### 3. Media Call PCAP Analysis (2 Marks)

- **L4 / L7 Protocols of the Video Call:**
  - **L4 (Transport):** **UDP** (low-latency, connectionless transport suited for real-time media without head-of-line blocking).
  - **L7 (Session / Media):** **STUN / TURN** (RFC 5389 / RFC 5766 / RFC 8656 on well-known UDP port `3478`) encapsulating encrypted real-time **SRTP** (Secure Real-Time Transport Protocol, WebRTC/VoIP media) streams.
- **Direct Peer-to-Peer vs. TURN Relay Endpoint:**
  - The hosts connect **via a TURN relay endpoint** at **`198.51.100.200:3478`**, **not** directly peer-to-peer.
  - Evidence from `orbit_incident.pcap`: Every single media packet (both audio and video, both inbound and outbound) is exchanged exclusively between `BRB-PC1` (`10.99.0.162`) and the single remote endpoint `198.51.100.200` on standard STUN/TURN port `3478`. Because `BRB-PC1` is behind `HQ-R1`'s PAT/NAT overload (`203.0.113.2`), direct ICE peer-to-peer traversal was bypassed in favor of TURN relaying.
- **How Audio vs. Video Packets Were Separated:**
  Three independent flow signatures in `orbit_incident.pcap` cleanly separate the two streams:
  1. **Distinct Client UDP Ports (5-Tuple):** Audio uses client UDP port **`50004`** (`10.99.0.162:50004 <-> 198.51.100.200:3478`), while video uses client UDP port **`50006`** (`10.99.0.162:50006 <-> 198.51.100.200:3478`) — following standard even-numbered RTP/SRTP port assignment (with odd ports `50005`/`50007` reserved for RTCP).
  2. **Packet Size Distribution:** Audio packets are small and constant at **`194 bytes`** (`orig_len`), whereas video packets are large and constant at **`1,250 bytes`** (`orig_len`) to carry compressed video frame slices.
  3. **Packet Rate & Bitrate:** Audio transmits at **`50 pkt/s`** per direction (`1,000` packets over `20 s`, matching standard `20 ms` voice packetization at **`77.6 kbps`** per direction), whereas video transmits at **`750 pkt/s`** per direction (`15,000` packets over `20 s`, **`7.50 Mbps`** per direction — ~97× the audio bandwidth).
