import argparse
import socket
import struct
import sys
from collections import defaultdict

CLIENT_IP = "10.99.0.162"
NDT7_SERVER_IP = "198.51.100.50"
NDT7_PORT = 3001


def read_pcap(pcap_path):
    """Yield (timestamp, orig_len, proto, src_ip, dst_ip, src_port, dst_port) from a libpcap file."""
    with open(pcap_path, "rb") as f:
        ghdr = f.read(24)
        if len(ghdr) < 24:
            return
        while True:
            phdr = f.read(16)
            if len(phdr) < 16:
                break
            ts_sec, ts_usec, incl_len, orig_len = struct.unpack("<IIII", phdr)
            data = f.read(incl_len)
            if len(data) < 34:
                continue
            eth_type = struct.unpack("!H", data[12:14])[0]
            if eth_type != 0x0800:
                continue
            ip_hdr = data[14:34]
            proto = ip_hdr[9]
            src_ip = socket.inet_ntoa(ip_hdr[12:16])
            dst_ip = socket.inet_ntoa(ip_hdr[16:20])
            src_port = dst_port = 0
            if proto in (6, 17) and len(data) >= 38:
                src_port, dst_port = struct.unpack("!HH", data[34:38])
            yield (ts_sec + ts_usec / 1_000_000.0, orig_len, proto, src_ip, dst_ip, src_port, dst_port)


def analyze_pcap(pcap_path):
    total_bytes = 0
    ndt_bytes = 0
    downlink_bytes = 0
    uplink_bytes = 0
    dl_ts = []
    ul_ts = []
    dl_buckets = defaultdict(int)
    ul_buckets = defaultdict(int)
    t0 = None

    for ts, orig_len, proto, src_ip, dst_ip, src_port, dst_port in read_pcap(pcap_path):
        total_bytes += orig_len
        if t0 is None:
            t0 = ts

        # Bug P1 fix: isolate only the NDT7 TCP speedtest flow (port 3001 between CLIENT_IP and NDT7_SERVER_IP)
        if proto != 6:
            continue
        is_downlink = (src_ip == NDT7_SERVER_IP and dst_ip == CLIENT_IP and src_port == NDT7_PORT)
        is_uplink = (src_ip == CLIENT_IP and dst_ip == NDT7_SERVER_IP and dst_port == NDT7_PORT)
        if not (is_downlink or is_uplink):
            continue

        ndt_bytes += orig_len
        # Bug P3 fix: 1-second relative time-series buckets from capture start t0
        bucket = int(ts - t0)

        # Bug P2 fix: correct downlink (server -> client) vs uplink (client -> server) direction
        if is_downlink:
            downlink_bytes += orig_len
            dl_ts.append(ts)
            dl_buckets[bucket] += orig_len
        else:
            uplink_bytes += orig_len
            ul_ts.append(ts)
            ul_buckets[bucket] += orig_len

    # Bug P2 fix: convert bytes -> Megabits (* 8 / 1e6) over each phase's active transfer window
    dl_duration = (max(dl_ts) - min(dl_ts)) if len(dl_ts) >= 2 else 1.0
    ul_duration = (max(ul_ts) - min(ul_ts)) if len(ul_ts) >= 2 else 1.0
    dl_mbps = (downlink_bytes * 8.0 / 1_000_000.0) / dl_duration if dl_duration > 0 else 0.0
    ul_mbps = (uplink_bytes * 8.0 / 1_000_000.0) / ul_duration if ul_duration > 0 else 0.0
    pct_ndt = (ndt_bytes / total_bytes * 100.0) if total_bytes else 0.0

    return {
        "download_mbps": dl_mbps,
        "upload_mbps": ul_mbps,
        "speedtest_pct": pct_ndt,
        "dl_buckets": dl_buckets,
        "ul_buckets": ul_buckets,
    }


def save_plot(result, out_path="throughput_timeseries.png"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    all_secs = sorted(set(result["dl_buckets"].keys()) | set(result["ul_buckets"].keys()))
    dl_vals = [result["dl_buckets"].get(s, 0) * 8.0 / 1_000_000.0 for s in all_secs]
    ul_vals = [result["ul_buckets"].get(s, 0) * 8.0 / 1_000_000.0 for s in all_secs]

    plt.figure(figsize=(10, 4.5))
    plt.plot(all_secs, dl_vals, label="Downlink (Mbps)", color="#1D4ED8", linewidth=2, marker="o", markersize=4)
    plt.plot(all_secs, ul_vals, label="Uplink (Mbps)", color="#DC2626", linewidth=2, marker="s", markersize=4)
    plt.xlabel("Relative Time (seconds)")
    plt.ylabel("Throughput (Mbps)")
    plt.title("NDT7 Speedtest Throughput Over Time (1-Second Bins)")
    plt.xticks(range(0, max(all_secs) + 1, 2) if all_secs else [0])
    plt.ylim(bottom=0)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"Saved plot to {out_path}")


def main():
    parser = argparse.ArgumentParser(description="Analyze NDT7 speedtest PCAP trace.")
    parser.add_argument("pcap", help="Path to PCAP file")
    parser.add_argument("--throughput", action="store_true", help="Print download_mbps,upload_mbps")
    parser.add_argument("--plot", action="store_true", help="Generate throughput_timeseries.png")
    args = parser.parse_args()

    res = analyze_pcap(args.pcap)
    if args.throughput:
        print(f"{res['download_mbps']:.2f},{res['upload_mbps']:.2f}")
        print(f"Speedtest traffic share: {res['speedtest_pct']:.1f}%", file=sys.stderr)
    if args.plot:
        save_plot(res)


if __name__ == "__main__":
    main()
